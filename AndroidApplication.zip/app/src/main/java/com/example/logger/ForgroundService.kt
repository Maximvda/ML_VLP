package com.example.logger

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.ConnectivityManager
import android.os.AsyncTask
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.jcraft.jsch.*
import org.json.JSONObject
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.*
import kotlin.collections.ArrayList


class ForegroundService : Service(), SensorEventListener {
    lateinit var mSensorManager: SensorManager
    lateinit var timeString: String
    private var timeLast = 0.toLong()

    val broadCastReceiver = object : BroadcastReceiver(){
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_ON -> startMeasurement()

                Intent.ACTION_SCREEN_OFF -> stopMeasurement()
            }
        }
    }

    val arrayList = ArrayList<Array<Float>>()
    val mValuesMagnet = FloatArray(3)
    val mValuesAccel = FloatArray(3)
    val mValuesOrientation = FloatArray(3)
    val mRotationMatrix = FloatArray(9)

    fun startMeasurement() {
        timeLast = System.nanoTime()
        val mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val mMagnetometer = mSensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        mSensorManager.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_NORMAL)
        mSensorManager.registerListener(this, mMagnetometer, SensorManager.SENSOR_DELAY_NORMAL)
    }


    fun measurement() {
        SensorManager.getRotationMatrix(mRotationMatrix, null, mValuesAccel, mValuesMagnet)
        SensorManager.getOrientation(mRotationMatrix, mValuesOrientation)
        val time = System.nanoTime()
        val diff = ((time - timeLast)/1000000).toFloat()
        timeLast = time
        val array = arrayOf<Float>((mValuesOrientation.get(0)),(mValuesOrientation.get(1)), (mValuesOrientation.get(2)), diff)
        arrayList.add(array)
        //val printarray = arrayOf<Float>(((mValuesOrientation.get(0)*180/Math.PI).toFloat()),((mValuesOrientation.get(1)*180/Math.PI).toFloat()), ((mValuesOrientation.get(2)*180/Math.PI).toFloat()), diff)
        //Log.v("Measurement", Arrays.toString(printarray))
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {

    }

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type){
            Sensor.TYPE_ACCELEROMETER -> System.arraycopy(
                event.values,
                0,
                mValuesAccel,
                0,
                3
            )

            Sensor.TYPE_MAGNETIC_FIELD -> System.arraycopy(
                event.values,
                0,
                mValuesMagnet,
                0,
                3
            )
        }
        measurement()
    }

    override fun onCreate() {
        super.onCreate()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0, notificationIntent, 0
        )
        val notification =
            NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Logging angles")
                .setContentText("Only logs when screen on")
                .setSmallIcon(R.mipmap.ic_launcher_round)
                .setContentIntent(pendingIntent)
                .build()
        startForeground(startId, notification)


        timeString = (System.currentTimeMillis()/1000).toString()
        mSensorManager = this.getSystemService(SENSOR_SERVICE) as SensorManager
        val intentFilter = IntentFilter()
        intentFilter.addAction(Intent.ACTION_SCREEN_ON)
        intentFilter.addAction(Intent.ACTION_SCREEN_OFF)

        startMeasurement()
        registerReceiver(broadCastReceiver, intentFilter)

        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        stopMeasurement()
        unregisterReceiver(broadCastReceiver)
    }

    fun stopMeasurement() {
        mSensorManager.unregisterListener(this)
        val cm = applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val isMetered = !cm.isActiveNetworkMetered
        val install = Installation
        val address = install.id(applicationContext) + "_"
        val fileParams = FileTaskParams(arrayList, address, cacheDir)
        val asyncSaveToFile = saveToFile()
        asyncSaveToFile.execute(fileParams)

        if (isMetered){
            val files = cacheDir.listFiles()
            val fileUpload = uploadHTTPS()
            fileUpload.execute(files)
        }
    }

    override fun onBind(intent: Intent): IBinder? {
        return null
    }

    companion object {
        const val CHANNEL_ID = "ForegroundServiceChannel"
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                CHANNEL_ID,
                "Foreground Service Channel",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            val manager = getSystemService(
                NotificationManager::class.java
            )
            manager!!.createNotificationChannel(serviceChannel)
        }
    }
}

class FileTaskParams internal constructor(var arrayList: ArrayList<Array<Float>>, var mac: String, var cacheDir: File)

class saveToFile: AsyncTask<FileTaskParams, Void?, Void?>() {
    override fun doInBackground(vararg params: FileTaskParams?): Void? {
        var string = ""
        for (meas in params[0]!!.arrayList){
            for (mes in meas){
                string += mes.toString() + ","
            }
            string += "\n"
        }
        //Try to save file
        try {
            val tempFile = File.createTempFile(params[0]!!.mac,".csv", params[0]!!.cacheDir)
            val writer = FileWriter(tempFile)
            writer.append(string)
            writer.flush()
            writer.close()
            params[0]!!.arrayList.clear()
        }
        catch (ioe: IOException)
        {
            ioe.printStackTrace();
        }
        return null
    }
}

class uploadHTTPS: AsyncTask<Array<File>, Void?, Void?>() {
    override fun doInBackground(vararg params: Array<File>): Void? {
        val files = params[0]
        try {
            for (file in files) {
                val fin = FileInputStream(file)
                val reader = BufferedReader(InputStreamReader(fin))
                val sb = StringBuilder()
                var line: String? = null
                while (reader.readLine().also { line = it } != null) {
                    sb.append(line).append("\n")
                }
                reader.close()
                val string = sb.toString()
                val split = file.absolutePath.split("/")
                val file_name = split[split.size-1]
                val data = JSONObject()
                data.put("file", file_name)
                data.put("data", string)
                data.put("pass", "rebOFOm'48jRgMne5")

                var out: OutputStream? = null
                val url = URL("https://homes.esat.kuleuven.be/~r0579568/json.php")

                val conn = url.openConnection() as HttpURLConnection
                conn.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
                conn.setRequestProperty("Accept","application/json");
                conn.requestMethod = "POST"
                conn.doOutput = true
                conn.doInput = true
                conn.connect()
                val os = DataOutputStream(conn.outputStream)
                os.writeBytes(data.toString())
                //val os = DataOutputStream(conn.outputStream)
                //os.writeBytes(URLEncoder.encode(data, "UTF-8"))
                os.flush()
                os.close()
                Log.i("STATUS", conn.responseCode.toString())
                Log.i("MSG", conn.responseMessage)
                conn.disconnect()

                file.delete()
            }
        } catch (e: java.lang.Exception) {
            println(e.message)
        }
        return null
    }
}

class SFTPConnection : AsyncTask<Array<File>, Void?, Void?>() {
    override fun doInBackground(vararg params: Array<File>): Void? {
        var session: Session? = null
        var channel: Channel? = null
        val config = Properties()
        val files = params[0]
        config["StrictHostKeyChecking"] = "no"
        try {
            val ssh = JSch()
            session = ssh.getSession("logger", "192.168.1.47", 2222)
            session.setPassword("logger")
            session.setConfig(config);
            session.connect()
            session.isConnected()
            channel = session.openChannel("sftp")
            channel.connect()
            val sftp: ChannelSftp? = channel as ChannelSftp?
            for (file in files) {
                sftp!!.put(file.absolutePath, "Download/logs/")
                file.delete()
            }

        } catch (e: JSchException) {
            // TODO Auto-generated catch block
            e.printStackTrace()
        } catch (e: SftpException) {
            // TODO Auto-generated catch block
            e.printStackTrace()
        }
        return null
    }
}

object Installation {
    private var sID: String? = null
    private const val INSTALLATION = "INSTALLATION"

    @Synchronized
    fun id(context: Context): String? {
        if (sID == null) {
            val installation =
                File(context.filesDir, INSTALLATION)
            sID = try {
                if (!installation.exists()) writeInstallationFile(installation)
                readInstallationFile(installation)
            } catch (e: Exception) {
                throw RuntimeException(e)
            }
        }
        return sID
    }

    @Throws(IOException::class)
    private fun readInstallationFile(installation: File): String {
        val f = RandomAccessFile(installation, "r")
        val bytes = ByteArray(f.length().toInt())
        f.readFully(bytes)
        f.close()
        return String(bytes)
    }

    @Throws(IOException::class)
    private fun writeInstallationFile(installation: File) {
        val out = FileOutputStream(installation)
        val id = UUID.randomUUID().toString()
        out.write(id.toByteArray())
        out.close()
    }
}
/*
class CallAPI : AsyncTask<String?, String?, String>() {
    override fun onPreExecute() {
        super.onPreExecute()
    }

    protected override fun doInBackground(vararg params: String): String {
        val urlString = params[0] // URL to call
        val data = params[1] //data to post
        var out: OutputStream? = null
        try {
            val url = URL(urlString)
            val urlConnection: HttpURLConnection = url.openConnection() as HttpURLConnection
            out = BufferedOutputStream(urlConnection.getOutputStream())
            val writer = BufferedWriter(OutputStreamWriter(out, "UTF-8"))
            writer.write(data)
            writer.flush()
            writer.close()
            out.close()
            urlConnection.connect()
        } catch (e: java.lang.Exception) {
            println(e.message)
        }
    }
}*/